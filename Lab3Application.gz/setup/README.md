# cs61lab3
## Alma and Jessie

## Setup
Our setup file loads in each JSON file as a collection in the database. To run the file do:
`mongo <monog options> MMSetup.js`

## Testing
Our test file prints out queries on the database, i.e. findOne().
