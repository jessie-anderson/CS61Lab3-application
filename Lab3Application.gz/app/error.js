const handleError = (err) => {
  console.log('An error occurred:');
  console.log(err);
};

export default handleError;
